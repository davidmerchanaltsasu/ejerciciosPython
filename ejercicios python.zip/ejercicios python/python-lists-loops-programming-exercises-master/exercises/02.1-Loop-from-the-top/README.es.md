# `02.1` Loop from the end

Este bucle está iterando la lista de principio a fin, incrementando uno en uno.

## 📝 Instrucciones:

1. Vamos a intentar iterar desde el fin hasta el principio.

## 💻 Resultado esperado:

```js
12
25
23
55
56432
48
23
867543
8
654
47889
4
5
3423
```
