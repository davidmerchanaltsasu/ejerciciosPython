---
tutorial: "https://www.youtube.com/watch?v=tFCstq-Us3I"
---

# `02.1` Loop from the end

This loop is *looping* the list from beginning to end, increasing one by one.

## 📝 Instructions:

1. Let's try looping from the end to the beginning.

## 💻 Expected result:

```py
12
25
23
55
56432
48
23
867543
8
654
47889
4
5
3423
```
