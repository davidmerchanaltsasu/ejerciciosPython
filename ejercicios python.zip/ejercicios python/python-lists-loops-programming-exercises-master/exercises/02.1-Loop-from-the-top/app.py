my_sample_list = [3423,5,4,47889,654,8,867543,23,48,56432,55,23,25,12]

# Modify the loop below to print from end to start

for i in range(0, len(my_sample_list)):
    print(my_sample_list[i])
