# `12.6` Transformers

## 📝 Instructions:

1. Define a new function called `data_transformer()` that receives a list as parameter.

2. The function should return a list of strings containing the full name of each user using the `map()` method.

## 💻 Expected result:

```py
['Mario Montes', 'Joe Biden', 'Bill Clon', 'Hilary Mccafee', 'Bobby Mc birth']
```
