# `12.6` Transformers

## 📝 Instrucciones:

1. Declara una nueva función llamada `data_transformer()` que reciba una lista como parámetro.

2. La función debe retornar una lista de strings con el nombre completo de cada usuario, debes hacerlo usando la función `map()`.

## 💻 Resultado esperado:

```py
['Mario Montes', 'Joe Biden', 'Bill Clon', 'Hilary Mccafee', 'Bobby Mc birth']
```
