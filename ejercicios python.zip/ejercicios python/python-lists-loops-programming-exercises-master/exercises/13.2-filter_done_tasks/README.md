# `13.2` Filter done tasks

## 📝 Instructions:

1. Use the `filter()` function to remove all the undone tasks from the tasks list and print the new list on the console.

## 💻 Expected result:

```py
[{'label': 'Eat my lunch', 'done': True}, {'label': 'Replit the finishes', 'done': True}, {'label': 'Read a book', 'done': True}]
```
