# `13.2` Filter done tasks

## 📝 Instrucciones:

1. Usa la función `filter()` para eliminar todas las tareas pendientes de la lista de tareas e imprime la nueva lista en la consola.

## 💻 Resultado esperado:

```py
[{'label': 'Eat my lunch', 'done': True}, {'label': 'Replit the finishes', 'done': True}, {'label': 'Read a book', 'done': True}]
```
