# `08` Delete element

La única forma de borrar a `Daniella` de la lista (sin trampas) sería crear una nueva lista con todas las demás personas, excepto `Daniella`.

## 📝 Instrucciones:

1. Por favor, crea una función `delete_person` que elimine a una persona dada de una lista y devuelva una nueva lista sin esa persona.

## 💻 Resultado esperado:

 ```py
Resultado:

['juan', 'ana', 'michelle', 'stefany', 'lucy', 'barak']
['ana', 'michelle', 'daniella', 'stefany', 'lucy', 'barak']
['juan', 'ana', 'michelle', 'daniella', 'stefany', 'lucy', 'barak']
```
