
# `05` Sum all items

## 📝 Instructions:

1. Complete the code of the function `sum_all_values` so that it returns the sum of all the items in `my_sample_list`.

## 💡 Hint:

+ You have to loop the entire list and add the value of each item into the `total` variable.

## 💻 Expected Result:

```py
925960
```
