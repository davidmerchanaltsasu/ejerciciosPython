# `05` Sum all items

## 📝 Instrucciones:

1. Completa el código de la función `sum_all_values` para que devuelva la suma de todos los elementos en la lista `my_sample_list`.

## 💡 Pista:

+ Tienes que iterar la lista entera y sumar el valor de cada elemento en la variable `total`.

## 💻 Resultado esperado:

```py
925960
```
