spanish_translations = { "dog": "perro", "house": "casa", "cat": "gato" }
# Your code here


# Don't touch the code below
print("Translation:", spanish_translations["dog"])
print(spanish_translations)
