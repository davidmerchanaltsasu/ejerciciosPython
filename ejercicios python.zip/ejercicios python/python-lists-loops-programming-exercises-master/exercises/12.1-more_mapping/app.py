my_numbers = [23,234,345,4356234,243,43,56,2]

# Your code here

print(new_list)
