my_list = [232,32,1,4,55,4,3,32,3,24,5,5,5,34,2,35,5365743,52,34,3,55]

# Your code here
for item in my_list:
    print(item)
