my_list = [4,5,734,43,45,100,4,56,23,67,23,58,45,3,100,4,56,23]

# Print in the console the 1st element on the list

# Print in the console the 4th element on the list
