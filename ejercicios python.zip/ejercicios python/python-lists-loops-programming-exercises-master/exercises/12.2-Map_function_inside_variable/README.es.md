# `12.2` Map function inside a variable

La variable `names` contiene muchos nombres (😒 daah...)

La función ya definida `prepender` devuelve lo que sea que se le pase pero agregando antes: `'My name is: '`.

## 📝 Instrucciones:

1. Por favor, mapea la lista de nombres usando la función `prepender` para crear una nueva lista que se parezca a esto:

## 💻 Resultado esperado:

```py
[ 'My name is: Alice',
  'My name is: Bob',
  'My name is: Marry',
  'My name is: Joe',
  'My name is: Hilary',
  'My name is: Stevia',  
  'My name is: Dylan' ]
```


