
# `02.3` Loop from the half to the end

Este bucle no está iterándolo todo... porque las variables `initial_value`, `stop_value` e `increasing_value` son iguales a cero.

## 📝 Instrucciones:

1. Cambia el valor de esas variables para hacer que el bucle imprima solo la segunda mitad de la lista.

2. ¡No cambies nada más que el valor de esas tres variables!

## 💻 Resultado esperado:

```py
23
48
56432
55
23
25
12
```
