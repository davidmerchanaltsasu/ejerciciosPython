# `08.1` Merge List

## 📝 Instrucciones:

Escribe una función `merge_list` que una dos listas y devuelva una nueva lista uniendo todos los valores de las dos listas.

 1. Declara una lista vacía.

 2. Itera las dos listas.

 3. Inserta los valores a la lista nueva.

 4. Imprime la nueva variable con las dos listas.

## 💡 Pistas:

+ Tendrás que iterar cada lista e insertar sus elementos en una nueva lista.

+ Hay más formas para combinar listas en Python. Este es un buen momento para buscar en Internet "cómo combinar listas en python".

## 💻 Resultado esperado:

```py
['Lebron', 'Aaliyah', 'Diamond', 'Dominique', 'Aliyah', 'Jazmin', 'Darnell', 'Lucas', 'Jake', 'Scott', 'Amy', 'Molly', 'Hannah', 'Lucas']
```


