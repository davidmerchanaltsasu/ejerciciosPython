my_list = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']

# 1. Print the 3rd item here

# 2. Change the value of 'thursday' to None

# 3. Print that position now here
