my_list = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']

# 1. Print the 3rd item here
print(my_list[2])
# 2. Change the value of 'thursday' to None
my_list[4] = None
# 3. Print that position now here
print(my_list[4])
