parking_state = [
  [1,1,1],
  [0,0,0],
  [1,1,2]
]

# Your code here
