# `13.3` Filter list string

## 📝 Instructions:

1. Given a list of `names` please create a function that filters the list with only the names that contain the given string.

2. The given string is `'am'`

3. The search should NOT be Case Sensitive.

## 💻 Expected result:

```py
['Liam', 'William', 'James', 'Benjamin', 'Amelia', 'Samuel', 'Camila']
```
