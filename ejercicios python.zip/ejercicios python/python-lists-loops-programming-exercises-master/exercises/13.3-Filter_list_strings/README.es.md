# `13.3` Filter list string

## 📝 Instrucciones:

1. Dada una lista de nombres (`names`), por favor, crea una función que filtre de la lista solo los nombres que contengan un texto o string dado.

2. El string es `'am'`

3. La búsqueda NO debería ser sensible a mayúsculas/minusculas (case sensitive).

## 💻 Resultado esperado:

```py
['Liam', 'William', 'James', 'Benjamin', 'Amelia', 'Samuel', 'Camila']
```
