# `06.1` Everything is Awesome

## 📝 Instrucciones:

1. Compara el elemento. Si es `1`, añade el número en la lista `new_list`.

2. Compara el elemento. Si es `0`, añade `Yahoo` en la lista `new_list`, en lugar del número.

## 💻 Resultado esperado:

```py
Ejemplo de salida para [0,0,1,1,0]:

'Yahoo',
'Yahoo',
1,
1,
'Yahoo'
```
