# `06.1` Everything is Awesome

## 📝 Instructions:

1. Compare the item; if it is `1`, push the number to the list `new_list`.

2. Compare the item; if it is `0`, push `Yahoo` to the list `new_list` (instead of the number).

## 💻 Expected Result:

```py
Example output for [0,0,1,1,0]:

'Yahoo',
'Yahoo',
1,
1,
'Yahoo'
```
