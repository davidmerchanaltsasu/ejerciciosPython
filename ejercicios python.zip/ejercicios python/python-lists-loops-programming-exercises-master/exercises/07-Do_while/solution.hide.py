# Your code here

number = 20

while number >= 1:
    if number % 5 == 0:
        print(str(number) + "!")
    else:
        print(number)
    number -= 1

print("LIFTOFF")
