# `07` Do While

DO DO DO. The `while()` function is another loop example in Python and is less commonly used, but it is still a loop.

```py
x = 1
while x < 6:
  print(x)
  x += 1
```

## 📝 Instructions:

1. Print every iteration number on the console from `20` to `1`, but **concatenate an exclamation mark** to the output if the number is a multiple of 5.

2. At the end print `LIFTOFF`.

## 💡 Hint:

+ https://www.w3schools.com/python/python_while_loops.asp

## 💻 Expected result:

```py
Example Output on the console:

20!
19
18
17
16
15!
14
13
12
11
10!
.
.
1
LIFTOFF
```

