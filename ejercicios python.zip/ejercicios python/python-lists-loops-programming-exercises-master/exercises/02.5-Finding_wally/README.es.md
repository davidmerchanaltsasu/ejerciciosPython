# `02.5` Finding Wally

## 📝 Instrucciones:

1. Encuentra a Wally 😊

2. Imprime la(s) posición(es) de Wally en la consola.

## 💡 Pista:

+ Usa un bucle `for` y un condicional `if`.

## 💎 Elemento sorpresa:

¿Qué pasa si hay más de un Wally?

## 💻 Resultado esperado:

```py
65
198
```
