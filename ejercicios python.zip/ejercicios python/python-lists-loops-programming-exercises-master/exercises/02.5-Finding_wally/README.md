---
tutorial: "https://www.youtube.com/watch?v=zez4r9ApjSY"
---

# `02.5` Finding Wally

## 📝 Instructions:

1. Find Wally 😊

2. Print the position(s) of Wally in the console.

## 💡 Hint:

+ Use a `for` loop and an `if` statement.

## 💎 Easter Egg:

What if there is more than one Wally?

## 💻 Expected result:

```py
65
198
```
