# `02.4` One last looping

## 📝 Instrucciones:

1. Cambia el valor del segundo elemento a `Steven`.

2. Establece el valor de la última posición a `Pepe`.

3. Asígnale al primer elemento, el valor del 3er elemento concatenado con el valor del 5to elemento.

4. Realiza un bucle en la lista en orden inverso (desde el final hasta el principio) e imprime todos los elementos...

## 💡 Pistas:

+ Recuerda que la posición inicial de la lista es 0.

+ Recuerda utilizar el bucle `for` en este ejercicio.

+ No debes utilizar ningún método para invertir la lista en lugar de `for`.

## 💻 Resultado esperado:

```py
Pepe
Bart
Cesco
Fernando
Lou
Maria
Pedro
Lebron
Ruth
Steven
RuthPedro
```
