# `01.5` Add items to the list

## 📝 Instrucciones:

1. Añade 10 números enteros aleatorios a la lista `my_list`.

## 💡 Pistas:

+ Tienes que importar el módulo "random": `import random`.

+ Usa la función `random.randint()` para obtener números aleatorios. Busca en Google "cómo usar la función randint".

