---
tutorial: "https://www.youtube.com/watch?v=blkw9_c-s8M"
---

# `01.5` Add items to the list

## 📝 Instructions:

1. Add 10 random integers to `my_list`.

## 💡 Hints:

+ You have to `import random` module.

+ Use the `random.randint()` function to get random numbers. Search on Google "how to use the randint function".

