# Remember to import random function here

my_list = [4, 5, 734, 43, 45]

# The magic goes below
