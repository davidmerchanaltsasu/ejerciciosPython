# `10` Find average

## 📝 Instrucciones:

1. Calcula el valor promedio de todos los elementos de la lista e imprímelo en la consola.

## 💡 Pistas:

+ Para imprimir el promedio, tienes que sumar todos los valores y dividir el total entre la cantidad de elementos de la lista.

+ Debes usar un bucle `for`.

+ Puedes usar tantas variables auxiliares como necesites.

## 💻 Resultado esperado:

```py
27278.8125
```
