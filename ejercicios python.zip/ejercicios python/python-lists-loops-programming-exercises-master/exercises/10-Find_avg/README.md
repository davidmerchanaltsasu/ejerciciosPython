# `10` Find average

## 📝 Instructions:

1. Calculate the average value of all the items in the list and print it on the console.

## 💡 Hints:

+ To print the average, you have to add all the values and divide the result by the total length of the list.

+ Make sure you are using a `for` loop.

+ You can use as many auxiliary variables as you need.

## 💻 Expected result:

```py
27278.8125
```
