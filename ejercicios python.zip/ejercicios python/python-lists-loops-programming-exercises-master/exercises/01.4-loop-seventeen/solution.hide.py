# Your code here, have fun:
for x in range(1,18):
    print(x)
