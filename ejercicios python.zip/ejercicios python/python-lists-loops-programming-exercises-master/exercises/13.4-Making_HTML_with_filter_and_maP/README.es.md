# `13.4` Making HTML with `filter` and `map` function

## 📝 Instrucciones:

1. Crea las funciones `generate_li` y `filter_colors` para hacer que el ejercicio imprima el siguiente HTML solo con colores cuya propiedad `sexy` sea `True`.

## 💻 Resultado esperado:

```py
['<li>Red</li>', '<li>Orange</li>', '<li>Pink</li>', '<li>Violet</li>']
```

## 💡 Pista:

+ Probablemente sea buena idea utilizar las funciones `filter()` y `map()`.
