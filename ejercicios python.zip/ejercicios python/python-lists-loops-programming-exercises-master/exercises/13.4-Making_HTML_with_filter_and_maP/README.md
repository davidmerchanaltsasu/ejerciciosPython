# `13.4` Making HTML with `filter` and `map` function

## 📝 Instructions:

1. Create `generate_li` and `filter_colors` functions to make the exercise print the following HTML with only the sexy colors:

## 💻 Expected result:

```py
['<li>Red</li>', '<li>Orange</li>', '<li>Pink</li>', '<li>Violet</li>']
```

## 💡 Hint:

+ You probably have to use `filter()` and `map()` function.
