# `04` Mixed list

## 📝 Instrucciones:

1. Escribe una función para imprimir en la consola los tipos de valores contenidos en la lista en cada posición.

2. Puedes usar el bucle `for`.

## 💡 Pistas:

- Puedes usar la función `type()` de Python.

- Recuerda que `len()` devuelve la longitud de tu lista.

## 💻 Resultado esperado:

```py
<class 'int'>
<class 'bool'>
<class 'str'>
<class 'list'>
<class 'str'>
<class 'float'>
<class 'dict'>
```


