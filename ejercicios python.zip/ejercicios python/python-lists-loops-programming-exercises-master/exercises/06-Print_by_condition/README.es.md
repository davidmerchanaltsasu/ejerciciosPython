# `06` Loop and print by condition

Es posible recorrer una lista usando un bucle `for` especificando además qué hacer en cada iteración del bucle.

## 📝 Instrucciones:

1. Por favor, modifica el código para imprimir solo los números **divisibles entre 14**.

## 💡 Pista:

+ Un número x es divisible entre 2 si: `(x % 2 == 0)`
