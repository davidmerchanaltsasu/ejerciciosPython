# `06` Loop and print by condition

It is possible to traverse a list using a `for` loop, also specifying what to do on each iteration of the loop.

## 📝 Instructions:

1. Please modify the code to print only the numbers **divisible by 14**.

## 💡 Hint:

+ A number x is divisible by 2 if: `(x % 2 == 0)`
