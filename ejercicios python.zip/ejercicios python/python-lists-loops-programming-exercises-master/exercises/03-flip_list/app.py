sample_list = [45, 67, 87, 23, 5, 32, 60]

# Your code below
