# `03` Flip list

## 📝 Instrucciones:

1. Crea la variable `new_list`.

2. Usando un bucle, invierte la lista `sample_list`.

3. Agrega el resultado del bucle a la variable `new_list`.

4. Con la función `print()` imprime en la consola el resultado obtenido.

## 💡 Pista:

- Deberías iterar la lista entera y meter los valores en la nueva lista a medida que avanzas.

## 💻 Resultado esperado:

```py
lista inicial:  [45, 67, 87, 23, 5, 32, 60]
lista final:    [60, 32, 5, 23, 87, 67, 45]
```
