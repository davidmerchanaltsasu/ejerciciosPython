my_sample_list = [3423,5,4,47889,654,8,867543,23,48,56432,55,23,25,12]

# Your code below, don't change anything above

for i in range(0, len(my_sample_list), 2):
    print(my_sample_list[i])
