---
tutorial: "https://www.youtube.com/watch?v=SJv6IgPick8"
---

# `02.2` Loop adding two

This code is looping the whole array, *one by one*.

## 📝 Instructions:

1. Change the loop so it loops *two by two* instead of *one by one*.

## 💻 Expected result:

```py
3423
4
654
867543
48
55
25
```
