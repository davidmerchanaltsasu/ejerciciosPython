# `02.2` Loop adding two

Este código está iterando la lista entera de *uno en uno*.

## 📝 Instrucciones:

1. Cambia el bucle para que itere de *dos en dos* en lugar de *uno en uno*.

## 💻 Resultado esperado:

```py
3423
4
654
867543
48
55
25
```
