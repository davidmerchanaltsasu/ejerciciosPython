---
tutorial: "https://www.youtube.com/watch?v=xMg9d0KsYAk"
---

# Welcome to Python Lists!

During this course, you will be learning the following concepts:

- What is a list.

- What is a tuple.

- Looping a list using `for`.

- Mapping lists.

- Filter a list.

- Creating a matrix.

- Merge lists.

- How to combine and use all these concepts in different ways.

Please click on the `Next →` button on the top right to proceed to the first exercise.

