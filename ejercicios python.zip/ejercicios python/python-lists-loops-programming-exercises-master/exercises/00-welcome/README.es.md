# Welcome to Python Lists!

En este curso aprenderás los siguientes conceptos:

- Qué es una lista.

- Qué es una tupla.

- Recorrer una lista usando `for`.

- Mapeo de listas.

- Filtrar una lista.

- Crear una matriz.

- Combinar dos listas.

- Cómo combinar y usar todos estos conceptos de diferentes maneras.

Por favor, presiona el botón de `Next →` de arriba a la derecha para ir al primer reto.

