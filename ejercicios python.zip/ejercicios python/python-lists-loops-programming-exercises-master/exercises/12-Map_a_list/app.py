celsius_values = [-2, 34, 56, -10]

def celsius_to_fahrenheit(celsius):
    # The magic happens here
   

result = list(map(celsius_to_fahrenheit, celsius_values))

print(result)
