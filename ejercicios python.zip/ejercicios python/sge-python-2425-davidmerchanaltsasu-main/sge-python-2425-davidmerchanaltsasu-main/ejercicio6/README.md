# Ejercicio6

Crea un programa que solicite un número al usuario y devuelva el siguiente mensaje:
- Si es mayor que 0: “Es un número positivo.”
- Si es igual a 0: “Es igual a cero.
- Si es menor que 0: “Es un número negativo.”