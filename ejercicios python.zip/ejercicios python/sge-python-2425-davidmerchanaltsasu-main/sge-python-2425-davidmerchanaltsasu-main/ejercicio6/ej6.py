# Paso 1: Solicitar al usuario un número
entrada = input("Introduce un número (puede ser negativo o decimal): ")

# Paso 2: Validar que la entrada sea un número (permitimos decimales y negativos)
try:
    numero = float(entrada)  # Usamos float para aceptar tanto enteros como decimales
except ValueError:
    print("Error: La entrada no es un número válido.")
else:
    # Paso 3: Evaluar si el número es positivo, negativo o cero
    if numero > 0:
        print("Es un número positivo.")
    elif numero == 0:
        print("Es igual a cero.")
    else:
        print("Es un número negativo.")
