# Diccionario con los usuarios y sus datos
usuarios = {
    "iperurena": {
        "nombre": "Iñaki",
        "apellido": "Perurena",
        "password": "123123"
    },
    "fmuguruza": {
        "nombre": "Fermín",
        "apellido": "Muguruza",
        "password": "654321"
    },
    "aolaizola": {
        "nombre": "Aimar",
        "apellido": "Olaizola",
        "password": "123456"
    }
}

# Máximo de intentos permitidos
MAX_INTENTOS = 3
intentos = 0
acceso_concedido = False

while intentos < MAX_INTENTOS:
    usuario_input = input("Introduce tu nombre de usuario: ")
    password_input = input("Introduce tu contraseña: ")

    # Verificar si el usuario existe
    if usuario_input in usuarios:
        # Verificar si la contraseña es correcta
        if usuarios[usuario_input]["password"] == password_input:
            nombre = usuarios[usuario_input]["nombre"]
            apellido = usuarios[usuario_input]["apellido"]
            print(f"\n✅ Acceso concedido. Bienvenido/a, {nombre} {apellido}.")
            acceso_concedido = True
            break
        else:
            print("❌ Contraseña incorrecta.\n")
    else:
        print("❌ Usuario no encontrado.\n")

    intentos += 1
    print(f"Intentos restantes: {MAX_INTENTOS - intentos}\n")

# Si no se logra acceder tras 3 intentos
if not acceso_concedido:
    print("🚫 Acceso denegado. Has agotado los 3 intentos.")