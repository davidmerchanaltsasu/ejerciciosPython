# Ejercicio15

Crea una programa de Login que compruebe el usuario y contraseña en el diccionario a continuación:
![Captura de pantalla 2024-12-19 a las 21.29.57.png](Captura%20de%20pantalla%202024-12-19%20a%20las%2021.29.57.png)

El usuario tendrá un máximo de 3 intentos, y al acceder correctamente se mostrará el nombre y apellido del usuario.