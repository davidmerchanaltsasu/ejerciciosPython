# Función para leer una lista de 5 números con validación
def leer_lista(numero_lista):
    numeros = []
    print(f"\nIntroduce 5 números para la Lista {numero_lista}:")
    for i in range(1, 6):
        while True:
            entrada = input(f"Número {i}: ")
            try:
                numero = int(entrada)
                numeros.append(numero)
                break
            except ValueError:
                print("Entrada inválida. Introduce un número entero válido.")
    return numeros

# Paso 1: Leer la primera lista
lista1 = leer_lista(1)

# Paso 2: Leer la segunda lista
lista2 = leer_lista(2)

# Paso 3: Encontrar los elementos comunes entre ambas listas
comunes = []
for numero in lista1:
    if numero in lista2 and numero not in comunes:
        comunes.append(numero)

# Paso 4: Mostrar resultados
print("\nLista 1:", lista1)
print("Lista 2:", lista2)
print("Elementos en común:", comunes)