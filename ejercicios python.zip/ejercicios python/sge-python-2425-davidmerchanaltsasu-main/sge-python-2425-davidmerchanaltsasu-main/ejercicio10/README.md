# Ejercicio10

Mejora el programa anterior para que solo permita 3 intentos. Cada vez que el usuario introduzca
datos de acceso incorrectos el programa mostrará el mensaje: “Datos incorrectos. Le quedan X
intentos.”, siendo X el número de intentos restantes. Tras el tercer fallo el programa mostrará el
mensaje “Has agotado todos tus intentos.” y finalizará.