# Ejercicio4

Escribe un programa que solicite al usuario una frase. A continuación le solicitará la letra que quiere
reemplazar y por qué letra deberá reemplazarse. Por último el programa mostrará el número de veces
que la letra está presente en la frase y el resultado final tras reemplazarla.
- Ejemplo: ‘Desarrollar es mi nuevo pasatiempos’, ‘a’,’e’
- Resultado: 4 apariciones. ‘Deserroller es mi nueve pesetiempos’