# Paso 1: Solicitar al usuario una frase
frase = input("Introduce una frase: ")

# Paso 2: Solicitar la letra a reemplazar
letra_original = input("¿Qué letra quieres reemplazar?: ")

# Validación: comprobar que solo se introdujo una letra
while len(letra_original) != 1:
    letra_original = input("Por favor, introduce SOLO UNA letra a reemplazar: ")

# Paso 3: Solicitar la nueva letra que se usará como reemplazo
letra_nueva = input("¿Por qué letra quieres reemplazarla?: ")

# Validación: comprobar que solo se introdujo una letra
while len(letra_nueva) != 1:
    letra_nueva = input("Por favor, introduce SOLO UNA letra como reemplazo: ")

# Paso 4: Contar cuántas veces aparece la letra a reemplazar
cantidad_apariciones = frase.count(letra_original)

# Paso 5: Reemplazar la letra en toda la frase
frase_modificada = frase.replace(letra_original, letra_nueva)

# Paso 6: Mostrar los resultados
print()
print("=====================================")
print(f"Apariciones de '{letra_original}': {cantidad_apariciones}")
print("Frase resultante:", frase_modificada)
print("=====================================")