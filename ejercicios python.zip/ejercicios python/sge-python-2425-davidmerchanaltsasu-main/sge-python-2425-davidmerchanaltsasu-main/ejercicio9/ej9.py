# Paso 1: Solicitar nombre de usuario
usuario = input("Introduce el nombre de usuario: ")

# Paso 2: Solicitar contraseña
contrasena = input("Introduce la contraseña: ")

# Paso 3: Verificar credenciales
if usuario == "root" and contrasena == "toor":
    print("¡Bienvenido!")
else:
    print("Acceso fallido")