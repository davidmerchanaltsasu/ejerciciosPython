# Lista predefinida con los valores a verificar
valores_validos = [6, 14, 11, 3, 2, 1, 15, 19]

# Función genérica para validar si un número está dentro de un rango
def validar_rango(numero, minimo, maximo):
    return minimo <= numero <= maximo

# Función genérica para comprobar si un número está en una lista
def comprobar_en_lista(numero, lista):
    return numero in lista

# Función que solicita un número entero dentro de un rango, con validación
def pedir_numero_en_rango(mensaje, minimo, maximo):
    while True:
        entrada = input(mensaje)
        if entrada.isdigit():
            numero = int(entrada)
            if validar_rango(numero, minimo, maximo):
                return numero
            else:
                print(f"⚠️ El número debe estar entre {minimo} y {maximo}.")
        else:
            print("❌ Entrada no válida. Debes introducir un número entero.")

# =============================
# PROGRAMA PRINCIPAL
# =============================
print("🔍 Comprobador de número en lista")
print("Introduce un número del 1 al 20.\n")

# Paso 1: Pedir número dentro del rango
numero_usuario = pedir_numero_en_rango("Número: ", 1, 20)

# Paso 2: Comprobar si el número está en la lista
if comprobar_en_lista(numero_usuario, valores_validos):
    print(f"✅ El número {numero_usuario} SÍ está en la lista.")
else:
    print(f"❌ El número {numero_usuario} NO está en la lista.")