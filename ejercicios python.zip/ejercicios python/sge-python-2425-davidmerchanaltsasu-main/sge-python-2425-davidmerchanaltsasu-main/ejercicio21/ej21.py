class Poligono:
    def __init__(self, lados, color="sin color"):
        self.lados = lados  # Lista de longitudes de lados
        self.color = color

    def perimetro(self):
        return sum(self.lados)

    def num_lados(self):
        return len(self.lados)

    def descripcion(self):
        return f"Polígono de {self.num_lados()} lados, color: {self.color}, perímetro: {self.perimetro()}"


import math

class Triangulo(Poligono):
    def __init__(self, lado1, lado2, lado3, color="sin color"):
        super().__init__([lado1, lado2, lado3], color)

        if not self._es_triangulo_valido():
            raise ValueError("Los lados no forman un triángulo válido.")

    def _es_triangulo_valido(self):
        a, b, c = self.lados
        return a + b > c and a + c > b and b + c > a

    def forma(self):
        a, b, c = self.lados
        if a == b == c:
            return "Equilátero"
        elif a == b or b == c or a == c:
            return "Isósceles"
        else:
            return "Escaleno"

    def area(self):
        a, b, c = self.lados
        s = self.perimetro() / 2
        return math.sqrt(s * (s - a) * (s - b) * (s - c))


class Cuadrado(Poligono):
    def __init__(self, lado, color="sin color"):
        super().__init__([lado, lado, lado, lado], color)

    def area(self):
        return self.lados[0] ** 2

    def es_cuadrado(self):
        return all(lado == self.lados[0] for lado in self.lados)


# Crear un triángulo equilátero
t = Triangulo(5, 5, 5, color="azul")
print("Triángulo:")
print("  Forma:", t.forma())
print("  Área:", t.area())
print("  Perímetro:", t.perimetro())
print("  Color:", t.color)
print()

# Crear un cuadrado
c = Cuadrado(4, color="verde")
print("Cuadrado:")
print("  Área:", c.area())
print("  Perímetro:", c.perimetro())
print("  Es cuadrado:", c.es_cuadrado())
print("  Color:", c.color)