# Ejercicio21

Continuando con el ejercicio anterior, crea una clase Poligono y otra llamada Cuadrado.
La clase Poligono será el padre de Triangulo y Cuadrado, y contendrá las propiedades y métodos
comunes de ambos. Ambos tendrán también otra propiedad llamada color.