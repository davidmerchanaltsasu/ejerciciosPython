# from collections import Counter
#
# numeros = [12, 23, 5, 12, 92, 5, 12, 5, 29, 92, 64, 23]
# frecuencias = Counter(numeros)
#
# print("Frecuencia de cada número:")
# print(dict(frecuencias))
#

# Lista de ejemplo con varios números repetidos
numeros = [12, 23, 5, 12, 92, 5, 12, 5, 29, 92, 64, 23]

# Diccionario para contar las repeticiones
frecuencias = {}

# Recorremos cada número en la lista
for numero in numeros:
    if numero in frecuencias:
        frecuencias[numero] += 1  # Si ya está, aumentamos el contador
    else:
        frecuencias[numero] = 1   # Si no está, lo agregamos con valor 1

# Mostramos el resultado
print("Frecuencia de cada número:")
print(frecuencias)