
# Paso 1: Solicitar el número de inicio
while True:
    inicio_input = input("Introduce el número de inicio: ")
    if inicio_input.lstrip("-").isdigit():
        inicio = int(inicio_input)
        break
    else:
        print("Por favor, introduce un número entero válido.")

# Paso 2: Solicitar el número de fin
while True:
    fin_input = input("Introduce el número de fin: ")
    if fin_input.lstrip("-").isdigit():
        fin = int(fin_input)
        break
    else:
        print("Por favor, introduce un número entero válido.")

# Paso 3: Determinar el orden (por si el usuario introduce primero el número mayor)
inicio_real = min(inicio, fin)
fin_real = max(inicio, fin)

# Paso 4: Calcular la suma de todos los enteros en ese rango (ambos incluidos)
suma = 0
for numero in range(inicio_real, fin_real + 1):  # +1 para incluir el número final
    suma += numero

# Paso 5: Mostrar el resultado
print(f"\nLa suma de los números entre {inicio_real} y {fin_real} es: {suma}")