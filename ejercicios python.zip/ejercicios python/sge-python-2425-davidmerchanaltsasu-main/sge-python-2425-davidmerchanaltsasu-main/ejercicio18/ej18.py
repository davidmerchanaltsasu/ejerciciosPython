class Robot:
    def __init__(self):
        # El robot empieza en la posición (0, 0)
        self.x = 0
        self.y = 0

    def mueve(self, orden):
        """
        Recibe una letra (A, R, I, D) y actualiza las coordenadas del robot.
        Cualquier otra entrada es ignorada con un mensaje de advertencia.
        """
        if orden.upper() == "A":
            self.y += 1  # Avanzar (hacia el norte)
        elif orden.upper() == "R":
            self.y -= 1  # Retroceder (hacia el sur)
        elif orden.upper() == "I":
            self.x -= 1  # Izquierda (hacia el oeste)
        elif orden.upper() == "D":
            self.x += 1  # Derecha (hacia el este)
        elif orden.lower() != "fin":
            print("⚠️ Orden no válida. Usa A, R, I o D.")

    def posicion_actual(self):
        """
        Devuelve la posición actual del robot como una tupla (x, y)
        """
        return (self.x, self.y)

miRobot = Robot()
orden = ""

print("🔧 Control del robot (A=adelante, R=retrocede, I=izquierda, D=derecha). Escribe 'fin' para terminar.\n")

while orden.lower() != 'fin':
    orden = input("Introduce la orden: ")
    if orden.lower() != 'fin':
        miRobot.mueve(orden)
        print(f"📍 Posición actual: {miRobot.posicion_actual()}")
