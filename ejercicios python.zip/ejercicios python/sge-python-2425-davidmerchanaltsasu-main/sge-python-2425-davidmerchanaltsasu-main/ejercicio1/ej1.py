
nombre="Michael Jordan"
edad=int(50)
media_puntos=float(28.5)
activo=bool(False)

print (nombre+str(edad)+str(media_puntos)+str(activo))