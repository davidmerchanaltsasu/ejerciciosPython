# Ejercicio1

Escribe un programa que contenga las siguientes variables:

- nombre: tipo string y valor “Michael Jordan”

- edad: tipo integer y valor 50

- media_puntos: tipo float y valor 28.5

- activo: False

El programa deberá mostrar en pantalla todos los valores.
