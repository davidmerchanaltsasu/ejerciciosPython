texto = input("Introduce un texto: ")

# Comprobamos que la cadena tenga al menos 3 caracteres
if len(texto) < 3:
    print("La cadena es demasiado corta. Debe tener al menos 3 caracteres.")
else:
    # Obtenemos los primeros 3 caracteres usando slicing
    primeros_3 = texto[:3]  # Desde el índice 0 hasta el 2 incluido

    # Obtenemos los últimos 3 caracteres
    ultimos_3 = texto[len(texto) - 3:]  # Desde len(texto) - 3 hasta el final

    # Concatenamos los dos fragmentos
    resultado = primeros_3 + ultimos_3

    # Mostramos el resultado en pantalla
    print("Resultado:", resultado)


# texto[0:4]	'prog'	Del índice 0 al 3 (4 no incluido).
# texto[:5]	'progr'	Desde el inicio hasta el índice 4.
# texto[5:]	'amación'	Desde el índice 5 hasta el final.
# texto[-3:]	'ón'	Últimos 3 caracteres (índices negativos van desde el final hacia el inicio).
# texto[:-4]	'programa'	Desde el inicio hasta el índice -4 (excluye los últimos 4).
# texto[::2]	'pormrcó'	Cada 2 letras, desde el principio.
# texto[::-1]	'nóicamárgorp'	Reverso de la cadena (paso negativo).
# texto[1:-1]	'rogramació'	Todo excepto el primer y último carácter.
# texto[3:9:2]	'gmc'	Desde el índice 3 al 8, de 2 en 2.

# 📚 Más ejemplos explicativos
# 1. Cortar una palabra por la mitad
#
# texto = "matemáticas"
# mitad = len(texto) // 2
# print(texto[:mitad])  # 'matemá'
# print(texto[mitad:])  # 'ticas'
#
# 2. Extraer solo vocales usando slicing (con paso)
#
# texto = "educación"
# # Esto no extrae vocales directamente, pero sí cada 2 caracteres
# print(texto[1::2])  # 'dució'
#
# 3. Extraer todo excepto los primeros y últimos 2 caracteres
#
# texto = "universidad"
# print(texto[2:-2])  # 'iversida'
#
# 4. Slicing con valores fuera del rango (no da error)
#
# texto = "hola"
# print(texto[0:100])  # 'hola'
# print(texto[-100:2]) # 'ho'
#
# 5. Invertir palabra por bloques
#
# texto = "informática"
# print(texto[-1:-6:-1])  # 'acitá'
#
# Esto toma desde el último carácter hacia atrás, 5 posiciones.
# 🧠 Recuerda:
#
#     En texto[inicio:fin], el inicio se incluye y el fin se excluye.
#
#     Los índices negativos empiezan desde el final (-1 es el último carácter).
#
#     Si no pones inicio, asume el 0; si no pones fin, asume el final.
#
#     paso permite saltos o invertir la secuencia.

