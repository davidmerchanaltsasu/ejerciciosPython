# Ejercicio2

Escribe un programa que genere un string compuesto por los primeros 3 caracteres y los últimos 3
caracteres de un string introducido por el usuario. 

Pista: tendrás que utilizar la función len() en la
obtención de los últimos 3 caracteres.
- Ejemplo 1: ‘aprendiendo’
- Resultado 1: ‘aprndo’
- Ejemplo 2: ‘escribiendo código’
- Resultado 2: ‘escigo’
