# Ejercicio11

Crea un programa que reciba 5 números del usuario y muestre el mayor de todos por pantalla.