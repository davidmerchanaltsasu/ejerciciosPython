# Paso 1: Crear una lista para almacenar los 5 números
numeros = []

# Paso 2: Pedir 5 números al usuario con validación
print("Introduce 5 números (pueden ser enteros o decimales):")
for i in range(1, 6):
    while True:
        entrada = input(f"Número {i}: ")
        try:
            numero = float(entrada)  # Convertimos a float para permitir decimales
            numeros.append(numero)
            break
        except ValueError:
            print("Entrada inválida. Por favor, introduce un número válido.")

# Paso 3: Encontrar el número mayor
mayor = max(numeros)

# Paso 4: Mostrar el resultado
print("\nEl número mayor de los introducidos es:", mayor)