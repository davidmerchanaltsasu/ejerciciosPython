# Ejercicio22

- Crea un paquete llamado calculadora.
- Dentro del paquete, crea dos módulos:
  - aritmetica.py: Contendrá funciones para sumar, restar, multiplicar y dividir. 
  - geometria.py: Contendrá una función para calcular el área de un círculo dado su radio.
- Implementa las funciones dentro de los módulos.
- Crea un script principal llamado main.py fuera del paquete, donde:
  - Importes las funciones del paquete. 
  - Llames a cada función para probarlas con diferentes valores.