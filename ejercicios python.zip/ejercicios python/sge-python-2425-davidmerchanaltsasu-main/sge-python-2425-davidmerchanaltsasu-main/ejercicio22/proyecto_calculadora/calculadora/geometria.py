# calculadora/geometria.py

import math

def area_circulo(radio):
    if radio < 0:
        raise ValueError("El radio no puede ser negativo.")
    return math.pi * radio ** 2