from calculadora.aritmetica import sumar, restar, multiplicar, dividir
from calculadora.geometria import area_circulo

print("🔢 Operaciones Aritméticas:")
print("Suma 5 + 3 =", sumar(5, 3))
print("Resta 10 - 4 =", restar(10, 4))
print("Multiplicación 7 * 6 =", multiplicar(7, 6))

try:
    print("División 12 / 4 =", dividir(12, 4))
    print("División 5 / 0 =", dividir(5, 0))  # Esto lanzará excepción
except ValueError as e:
    print("Error:", e)

print("\n🧮 Cálculo de área:")
try:
    print("Área de un círculo con radio 3 =", area_circulo(3))
    print("Área de un círculo con radio -2 =", area_circulo(-2))  # Esto lanzará excepción
except ValueError as e:
    print("Error:", e)