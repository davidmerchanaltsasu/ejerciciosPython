# Paso 1: Crear una lista para almacenar los 5 números
numeros = []

# Paso 2: Pedir 5 números al usuario con validación
print("Introduce números (pueden ser enteros o decimales):")
entrada=0
while (entrada!="fin"):
    entrada = input("Número : ")
    numero = float(entrada)  # Convertimos a float para permitir decimales
    numeros.append(numero)
    mayor = max(numeros)


# Paso 4: Mostrar el resultado
print("\nEl número mayor de los introducidos es:", mayor)