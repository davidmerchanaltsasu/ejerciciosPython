# Ejercicio8

Mejora el programa anterior para que muestre por separado la suma de los números pares y los
impares.
Ejemplo:
- Introduce el número de inicio: 4
- Introduce el número de fin: 8
- Los pares suman 18 y los impares 12