# Ejercicio19

Mejora el ejercicio anterior de forma que el robot pueda recibir una secuencia de movimientos.
Por ejemplo:
-  mueve(“AADDADIR”)
También deberá tener otros dos métodos: uno que devuelva todas las órdenes recibidas y otro capaz
de listar los movimientos necesarios para volver a la posición inicial (0,0).
Aquí tienes un ejemplo de una posible ejecución del programa:
![Captura de pantalla 2024-12-19 a las 21.36.17.png](Captura%20de%20pantalla%202024-12-19%20a%20las%2021.36.17.png)