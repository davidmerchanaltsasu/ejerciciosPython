class Robot:
    def __init__(self):
        self.x = 0
        self.y = 0
        self._historial_ordenes = ""  # Almacena todas las órdenes recibidas

    def mueve(self, ordenes):
        """
        Recibe una secuencia de órdenes como una cadena y actualiza la posición del robot.
        Las órdenes válidas son: A (arriba), R (abajo), I (izquierda), D (derecha).
        """
        for orden in ordenes.upper():
            if orden == "A":
                self.y += 1
            elif orden == "R":
                self.y -= 1
            elif orden == "I":
                self.x -= 1
            elif orden == "D":
                self.x += 1
            else:
                print(f"⚠️ Orden ignorada: '{orden}' no es válida.")
            self._historial_ordenes += orden

    def posicion_actual(self):
        """
        Devuelve una tupla con la posición actual del robot (x, y).
        """
        return (self.x, self.y)

    def ordenes_recibidas(self):
        """
        Devuelve una cadena con todas las órdenes recibidas desde el inicio.
        """
        return self._historial_ordenes

    def secuencia_para_volver(self):
        """
        Calcula la secuencia mínima de movimientos para volver a la posición inicial (0, 0).
        """
        secuencia = ""
        if self.x > 0:
            secuencia += "I" * self.x
        elif self.x < 0:
            secuencia += "D" * abs(self.x)
        if self.y > 0:
            secuencia += "R" * self.y
        elif self.y < 0:
            secuencia += "A" * abs(self.y)
        return secuencia


# Instanciamos el robot
miRobot = Robot()

print("🔧 Control del robot. Introduce secuencias de órdenes (A, R, I, D). Escribe 'fin' para terminar.\n")

orden = ""
while orden.lower() != "fin":
    orden = input("Introduce la orden: ")
    if orden.lower() != "fin":
        miRobot.mueve(orden)
        print(f"📍 Posición actual: {miRobot.posicion_actual()}")

# Mostrar resultados al finalizar
print("\n📜 Órdenes recibidas:", miRobot.ordenes_recibidas())
print("🔁 Secuencia para volver a (0,0):", miRobot.secuencia_para_volver())

