# Ejercicio3

Escribe un programa que solicite al usuario dos números y una frase. El primer número introducido
se corresponderá a la posición de inicio del substring que deberá mostrar el programa por pantalla.
El segundo número indicará la longitud de dicho substring.

- Ejemplo 1: Posicion=4, Longitud=8, Frase=’Desarrollar es mi nueva afición’ 
- Resultado 1: “rrollar “
- Ejemplo 2: Posicion=8, Longitud=11, Frase=’Bienvenido a la clase de programación’
- Resultado 2: “do a la cla”