posicion=int(input("introduce numero de posicion inicial"))

longitud=int(input("introduce longitud del substring a generar"))

frase=(input("introduce frase"))

final=posicion+longitud

print (frase[posicion:final])