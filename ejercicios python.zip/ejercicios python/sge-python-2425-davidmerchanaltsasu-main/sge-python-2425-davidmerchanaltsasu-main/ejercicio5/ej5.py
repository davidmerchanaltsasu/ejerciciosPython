# Paso 1: Solicitar al usuario un número del 1 al 10
numero = input("Introduce un número del 1 al 10: ")

# Paso 2: Validación - asegurar que el input es un número entero en el rango correcto
while not numero.isdigit() or not (1 <= int(numero) <= 10):
    numero = input("Número inválido. Introduce un número del 1 al 10: ")

# Convertimos el número a entero (ya validado)
numero = int(numero)

# Paso 3: Mostrar la tabla de multiplicar del número
print(f"\nTabla de multiplicar del {numero}:")
print("=" * 30)

for i in range(1, 11):  # Del 1 al 10 inclusive
    resultado = numero * i
    print(f"{numero} x {i} = {resultado}")

print("=" * 30)
