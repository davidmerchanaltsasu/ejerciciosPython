# Ejercicio20

Crea la clase Triangulo que almacene la longitud de cada uno de sus lados. Deberá contener los
siguientes métodos:
- area(): devuelve el área del triángulo
- forma(): indica si se trata de un triángulo equilátero, isósceles o irregular.
- perímetro(): devuelve el perímetro del triángulo.