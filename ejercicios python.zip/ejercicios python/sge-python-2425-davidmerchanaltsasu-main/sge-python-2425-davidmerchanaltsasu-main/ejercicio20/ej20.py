import math

class Triangulo:
    def __init__(self, lado1, lado2, lado3):
        self.lado1 = lado1
        self.lado2 = lado2
        self.lado3 = lado3

        if not self._es_triangulo_valido():
            raise ValueError("Los lados no forman un triángulo válido.")

    def _es_triangulo_valido(self):
        """
        Verifica si los tres lados forman un triángulo válido (regla del triángulo).
        """
        a, b, c = self.lado1, self.lado2, self.lado3
        return a + b > c and a + c > b and b + c > a

    def perimetro(self):
        """
        Devuelve el perímetro del triángulo.
        """
        return self.lado1 + self.lado2 + self.lado3

    def area(self):
        """
        Calcula el área usando la fórmula de Herón:
        s = (a + b + c) / 2
        área = sqrt[s(s-a)(s-b)(s-c)]
        """
        s = self.perimetro() / 2  # semiperímetro
        a, b, c = self.lado1, self.lado2, self.lado3
        area = math.sqrt(s * (s - a) * (s - b) * (s - c))
        return area

    def forma(self):
        """
        Devuelve el tipo de triángulo según sus lados.
        """
        a, b, c = self.lado1, self.lado2, self.lado3
        if a == b == c:
            return "Equilátero"
        elif a == b or b == c or a == c:
            return "Isósceles"
        else:
            return "Escaleno"  # También llamado Irregular
