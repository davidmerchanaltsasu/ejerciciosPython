from random import randint

# Generamos un número aleatorio entre 1 y 10
numero_secreto = randint(1, 10)

# Función que evalúa el intento del usuario
def evaluar_intento(intento, numero_objetivo):
    if intento < numero_objetivo:
        print("El número es más alto.")
        return False
    elif intento > numero_objetivo:
        print("El número es más bajo.")
        return False
    else:
        print("¡Has acertado! 🎉")
        return True

# Mensaje inicial
print("🔢 Adivina el número secreto (entre 1 y 10).")

# Bucle principal de intentos
acertado = False
while not acertado:
    entrada = input("Introduce tu número: ")

    # Validación de que sea un número entero válido
    if not entrada.isdigit():
        print("❌ Por favor, introduce un número entero válido entre 1 y 10.\n")
        continue

    intento = int(entrada)

    if intento < 1 or intento > 10:
        print("⚠️ El número debe estar entre 1 y 10.\n")
        continue

    # Llamamos a la función para evaluar el intento
    acertado = evaluar_intento(intento, numero_secreto)


