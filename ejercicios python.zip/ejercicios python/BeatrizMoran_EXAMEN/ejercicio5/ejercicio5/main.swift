//
//  main.swift
//  ejercicio5
//
//  Created by  on 10/2/25.
//

import Foundation
enum TipoHabitacion{
    case simple
    case doble
    case suite
}

enum ErrorDeReserva{
    case yaOcupada
    case noDisponible
}

protocol Reservable{
    var ocupada: Bool {get set}
    
    func reservar()
}

class Habitacion: Reservable{
   var numero: Int
    var tipo: TipoHabitacion
    var ocupada: Bool
    
    init(numero: Int, tipo: TipoHabitacion, ocupada: Bool){
        self.numero = numero
        self.tipo = tipo
        self.ocupada = ocupada
    }
    
    func reservar(){
        if !ocupada{
            self.ocupada = true
        }
        else{
            print("Error al intentar reservar la habitacion: " , ErrorDeReserva.yaOcupada)
        }
    }
    
    func liberar(){
        if ocupada{
            ocupada = false
        }
    }
    
}

class Hotel{
    var nombre: String
    var habitaciones: [Habitacion] = []
    
    init(nombre: String, habitaciones: [Habitacion]) {
        self.nombre = nombre
        self.habitaciones = habitaciones
    }
    
    func buscarHabitacionDisponible(tipo: TipoHabitacion) -> Habitacion?{
        for habitacion in habitaciones{
            if habitacion.tipo == tipo{
                return habitacion
            }
        }
        return nil
    }
    
    func reservarHabitacion(tipo: TipoHabitacion){
        var contador = 0
        for habitacion in habitaciones{
            if habitacion.tipo == tipo && !habitacion.ocupada {
                habitacion.ocupada = true
                contador += 1
                print("Habitacion reservada con exito")
                break
            }
        }
        if contador == 0{
            print("Error al intentar reservar la habitacion: " , ErrorDeReserva.noDisponible)
        }
    }
}

let hab1 = Habitacion(numero: 1, tipo: TipoHabitacion.doble, ocupada: false)
let hab2 = Habitacion(numero: 2, tipo: TipoHabitacion.simple, ocupada: true)
let hab3 = Habitacion(numero: 3, tipo: TipoHabitacion.suite, ocupada: false)

var habitaciones: [Habitacion] = [hab1, hab2, hab3]

//reservar habitacion1

print("Disponibilidad de la habitacion 1:", hab1.ocupada)

hab1.reservar()

print("Disponibilidad de la habitacion 1:", hab1.ocupada)

//intentar reservar habitacion ocupada:

hab1.reservar()

let hotel1 = Hotel(nombre: "Hotel1", habitaciones: habitaciones)

//buscar habitacion
var habitacionTipo = hotel1.buscarHabitacionDisponible(tipo: TipoHabitacion.simple)


if habitacionTipo != nil{
    print("Numero de hotel: " , habitacionTipo?.numero, "Tipo: ", habitacionTipo?.tipo)
}
else{
    print(ErrorDeReserva.noDisponible)
}

//reservar habitacion no disponible
hotel1.reservarHabitacion(tipo: TipoHabitacion.simple)

//reservar habitacion  disponible
hotel1.reservarHabitacion(tipo: TipoHabitacion.suite)



