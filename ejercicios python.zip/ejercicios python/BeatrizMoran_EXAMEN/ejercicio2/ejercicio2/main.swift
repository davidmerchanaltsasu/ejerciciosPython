//
//  main.swift
//  ejercicio2
//
//  Created by  on 10/2/25.
//

import Foundation
var tareas: [String] = []

func mostrarTareas(tareas: [String]) -> String{
    var listaTareas = "Tareas: \n"
    for tarea in tareas{
        listaTareas += String(tarea) + "\n"
    }
    return listaTareas
}

repeat {
    let menu: String = "1- Agregar una tarea \n2.- Ver todas las tareas \n3.- Salir"
    print(menu)
    print("Selecciona una opcion")
    
    guard let opcion = readLine(), !opcion.isEmpty else {
        print("Error: Introduce una opcion valida.")
        continue
    }
    
    if opcion.lowercased() == "salir" {
        break
    }
    
    switch opcion{
    case "1":
        print("Introduce una nueva tarea: ")
        guard let tarea = readLine(), !tarea.isEmpty else {
            print("Error: Introduce una tarea valida.")
            continue
        }
        tareas.append(tarea)
    case "2":
        let listaTareas = mostrarTareas(tareas: tareas)
        print(listaTareas)
    default:
        print("error, introduce una opcion valida")
    }

} while true


