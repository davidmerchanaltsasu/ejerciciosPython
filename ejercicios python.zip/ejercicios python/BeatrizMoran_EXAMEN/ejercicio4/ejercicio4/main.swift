//
//  main.swift
//  ejercicio4
//
//  Created by  on 10/2/25.
//

import Foundation

func fooBarQuix(_ numero:Int){
    for i in 1...numero{
        var contador = 0
        var resultado: String = ""
        
        if i % 3 == 0{
            resultado += "Foo"
            contador += 1
        }
        if i % 5 == 0{
            resultado += "Bar"
            contador += 1
        }
         if i % 7 == 0{
            resultado += "Qix"
             contador += 1
        }
         if String(i).contains("3"){
            resultado += "Foo"
             contador += 1
        }
         if String(i).contains("5"){
            resultado += "Bar"
             contador += 1
        }
         if String(i).contains("7"){
            resultado += "Qix"
             contador += 1
        }
        
        
        if contador == 0{
            print(i)
        }else{
            print(resultado)
        }
   }
}


print("Introduce un numero: ")
if let input = readLine(), let num = Int(input){
    fooBarQuix(num)

}
else{
    print("Error,. Introduce un numero entero")
}

