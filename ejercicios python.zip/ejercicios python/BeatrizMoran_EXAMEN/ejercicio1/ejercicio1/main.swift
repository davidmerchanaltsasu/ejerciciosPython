//
//  main.swift
//  ejercicio1
//
//  Created by  on 10/2/25.
//

import Foundation

func analizarTexto(_ texto: String) -> (vocales: Int, consonantes: Int, espacios: Int){
    var consonantes = 0
    var vocales = 0
    var espacios = 0
    for c in texto.lowercased(){
        if c == " "{
            espacios += 1
        }
        else if c == "a" || c == "e" || c == "i" || c == "o" || c == "u"{
            vocales += 1
        }
        else{
            consonantes += 1
        }
    }
    return (vocales, consonantes, espacios)
}

print(analizarTexto("Hello World"))

print(analizarTexto("Hola mundo, esto es un examen"))

