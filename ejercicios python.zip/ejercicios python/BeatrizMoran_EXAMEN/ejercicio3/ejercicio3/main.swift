//
//  main.swift
//  ejercicio3
//
//  Created by  on 10/2/25.
//

import Foundation

struct Precio{
   var precio: Double = 0.0
}
struct Producto{
    var nombre: String
    var precio: Double
    var cantidadEnStock: Int
    

    func disponible() -> Bool{
        if self.cantidadEnStock > 0{
            return true
        }
        else{
            return false
        }
    }
    
    func aplicarDescuento(porcentaje: Double) -> Double{
        return precio - ((precio * porcentaje) / 100)
    }
    
    var listaProductos: [Producto] = []
    


}

//sin aplicar descuento
var listaProductos: [Producto] = []


let prod1 = Producto(nombre: "pan", precio: 2.2, cantidadEnStock:2)
let prod2 = Producto(nombre: "Leche", precio: 3.2, cantidadEnStock: 10)
let prod3 = Producto(nombre: "Agua", precio: 1.12, cantidadEnStock: 20)
let prod4 = Producto(nombre: "Arroz", precio: 4.3, cantidadEnStock: 0)
listaProductos.append(prod1)
listaProductos.append(prod2)
listaProductos.append(prod3)
listaProductos.append(prod4)

func mostrarProductosDisponibles(){
    for prod in listaProductos{
        if prod.disponible(){
            print("Productos disponibles:" +
                "Nombre: " + prod.nombre + " Precio: " + String(prod.precio) + " Cantidad en stock: " + String(prod.cantidadEnStock))
        }
      
    }
}
mostrarProductosDisponibles()
// aplicar descuento
print(prod1.aplicarDescuento(porcentaje: 20))
