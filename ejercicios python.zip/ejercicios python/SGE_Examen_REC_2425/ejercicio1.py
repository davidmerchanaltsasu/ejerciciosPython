
def expand(listas: list[str]):

    cadena = "".join([lista[::-1] for lista in listas])
    print(cadena)

def revertir(cadena: str):

    return cadena[::-1]

expand(["cadena1", "cadena2", "cadena3"])
expand(["abc", "abc", "abc"])

# def revertir(cadena: str) -> str:
#     return cadena[::-1]
#
# def expand(listas: list[str]) -> str:
#     return "".join([revertir(cadena) for cadena in listas])
#
# # Pruebas
# print(expand(["cadena1", "cadena2", "cadena3"]))  # 1anedac2anedac3anedac
# print(expand(["abc", "abc", "abc"]))              # cbacbacba