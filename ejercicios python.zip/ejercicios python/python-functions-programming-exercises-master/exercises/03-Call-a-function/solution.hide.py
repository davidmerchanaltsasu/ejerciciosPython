def calculate_area(length, width):
	return length * width

# Your code below this line
square_area1 = calculate_area(4,4)
square_area2 = calculate_area(2,2)
square_area3 = calculate_area(5,5)
