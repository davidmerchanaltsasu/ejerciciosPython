def calculate_area(length, width):
	return length * width

# Your code below this line
