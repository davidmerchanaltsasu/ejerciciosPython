def sum(number1,number2):
    return number1 + number2

# Your code here
super_duper = sum(3445324,53454423)
print(super_duper)
