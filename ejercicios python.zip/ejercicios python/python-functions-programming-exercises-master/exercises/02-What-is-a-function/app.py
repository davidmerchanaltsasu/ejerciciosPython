def sum(number1,number2):
    return number1 + number2

# Your code here
total = sum(2,3)
print(total)
