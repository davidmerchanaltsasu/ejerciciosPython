---
intro: "https://www.youtube.com/watch?v=SD9lqR67yMY"
---
# Welcome to Python Functions!

¡¡Nos entusiasma mucho tenerte aquí!! 🎉 😂

Presiona `Next →` en la esquina superior derecha cuando quieras empezar.

En este curso aprenderás los siguientes conceptos:

1. Cómo crear y llamar funciones.

2. Construir tus primeras funciones.

3. Practicar las funciones Lambda de Python.

4. Construir funciones con parámetros.

5. Ejemplos de la vida real con funciones.

## Contributors

Thanks goes to these wonderful people ([emoji key](https://github.com/kentcdodds/all-contributors#emoji-key)):

1. [Alejandro Sanchez (alesanchezr)](https://github.com/alesanchezr), contribution: (coder) 💻, (idea) 🤔, (build-tests) ⚠️, (pull-request-review) 🤓, (build-tutorial) ✅, (documentation) 📖
2. [Paolo (plucodev)](https://github.com/plucodev), contribución: (bug reports) 🐛, (coder) 💻, (traducción) 🌎
3. [Marco Gómez (marcogonzalo)](https://github.com/marcogonzalo), contribución: (bug reports) 🐛, (traducción) 🌎

This project follows the [all-contributors](https://github.com/kentcdodds/all-contributors) specification. Contributions of any kind are welcome!
