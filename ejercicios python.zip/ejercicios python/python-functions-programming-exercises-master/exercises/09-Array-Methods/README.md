---
tutorial: "https://www.youtube.com/watch?v=5Wk2a16nnUY"
---

# `09` List Methods

## 📝 Instructions:

1. Write a function called `sort_names` that, given a list of names, returns them in alphabetical order.

## 💡 Hints:

+ Every list comes with default functions that allow sorting - use them inside your function!

+ Stuck on sorting? Read the W3 Schools page on sorting lists:

https://www.w3schools.com/python/ref_func_sorted.asp
