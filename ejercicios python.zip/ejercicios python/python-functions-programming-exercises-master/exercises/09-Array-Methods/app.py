names = ['John', 'Kenny', 'Tom', 'Bob', 'Dilan']

## CREATE YOUR FUNCTION HERE


print(sort_names(names))
