---
tutorial: "https://www.youtube.com/watch?v=Ne8ZRZTSaQA"
---

# `09` List Methods

## 📝 Instrucciones:

1. Escribe una función llamada `sort_names` que dada una lista de nombres, los devuelva en orden alfabético.

## 💡 Pistas:

- Cada lista viene con funciones predeterminadas que permiten ordenarla, ¡úsalas dentro de tu función!

+ ¿Atascado? Lee esta página sobre cómo ordenar listas:

https://www.freecodecamp.org/espanol/news/python-ordenar-lista-con-sort-ascendente-y-descendente-explicado-con-ejemplos/
