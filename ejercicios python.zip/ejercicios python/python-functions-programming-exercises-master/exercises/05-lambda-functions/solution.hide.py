# Your function here

is_odd = lambda num: num % 2 != 0
