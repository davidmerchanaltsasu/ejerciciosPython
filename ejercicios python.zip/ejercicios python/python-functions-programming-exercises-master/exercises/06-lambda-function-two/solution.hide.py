rapid = lambda myStr: myStr[:-1]

# Your code above, please do not change code below
print(rapid("bob")) # Should print "bo"
