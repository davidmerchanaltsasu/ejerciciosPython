# Define below the function called "multi" that expects 2 parameters
def multi(num1, num2):
    total = num1 * num2
    return total
# Don't edit anything below this line
return_value = multi(7,53812212)
print(return_value)
