---
tutorial: "https://www.youtube.com/watch?v=-HQtwsBnbMQ"
---

# `14` Create A For Loop

Loops are very useful. You don't have to rewrite the same lines many times.

The `for` loop lets you run the same code for different values.

## 📝 Instructions:

1. Complete the function called `standards_maker`.

2. The function has to print 300 times the phrase "I will ask questions if I am stuck".

3. Call the function `standards_maker()`.

## 💡 Hint:

+ You can use the `range()` function in the for loop.

## 🔎 Important:

+ Read more on loops: https://www.w3schools.com/python/python_for_loops.asp
