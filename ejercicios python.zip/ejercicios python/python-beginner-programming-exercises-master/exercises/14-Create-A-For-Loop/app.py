def standards_maker():
    # ✅↓ Write your code here ↓✅


# ✅↓ remember to call the function outside (here) ↓✅
