def fizz_buzz():
    # ✅↓ Write your code here ↓✅

# ❌↓ DON'T CHANGE THE CODE BELOW ↓❌
fizz_buzz()
