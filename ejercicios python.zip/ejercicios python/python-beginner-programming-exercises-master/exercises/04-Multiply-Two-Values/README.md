---
tutorial: "https://www.youtube.com/watch?v=tATIrAWiLLU"
---

# `04` Multiply Two Values

Any programming language lets you do basic Math operations like multiplication, division, etc.

To multiply 2 values in Python, you have to use the asterisk operator like this:

```py
resulting_value = 2 * 3
```

In this case, we stored the resulting value of the multiplication into a variable called `resulting_value`.

## 📝 Instructions:

1. Please store the result of multiplying 2345 times 7323 in a variable called `variables_are_cool`.

2. Now print the result in the console.
