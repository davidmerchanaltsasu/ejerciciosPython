---
tutorial: "https://www.youtube.com/watch?v=p4PY8s6asfw"
---

# `04` Multiply Two Values

Cualquier lenguaje de programación te permite realizar operaciones matemáticas básicas como multiplicación, división, etc.

Para multiplicar dos valores en Python, tienes que usar el operador estrella o asterisco de esta forma:

```py
resulting_value = 2 * 3
```

En este caso, hemos almacenado el resultado de la multiplicación en una variable llamada `resulting_value`.

## 📝 Instrucciones:

1. Por favor, almacena el resultado de multiplicar 2345 por 7323 en una variable llamada `variables_are_cool`.

2. Ahora imprime el resultado en la consola.