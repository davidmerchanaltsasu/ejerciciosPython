# ✅ ↓ your code here ↓ ✅

color = "red"
item = "marker"
print(color, item)
