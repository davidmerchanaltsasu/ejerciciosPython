# `17` Russian Roulette

Have you ever played Russian Roulette? It's super fun! If you make it (muahahahaha).

The revolver gun has only 6 slots for bullets... insert one bullet in one of the slots, spin the revolver chamber to make the game random, nobody knows the bullet position.

FIRE!!!...... are you dead?

## 📝 Instructions:

1. The game is almost working, please fill the function `fire_gun` to make the game work.

2. Compare the bullet position against the chamber position.

3. If the bullet position is equal to the chamber position, then the function should return `You are dead!`, else it should return `Keep playing!`

## 💡 Hints:

+ You can get the chamber position by calling the `spin_chamber` function

+ If the bullet is at the same slot as the revolver chamber, then it will be fired (`You are dead!`).
