a = '</title>'
b = '</html>'
c = '<head>'
d = '</body>'
e = '<html>'
f = '</head>'
g = '<title>'
h = '<body>'

# ❌ ⬆ DON'T CHANGE THE CODE ABOVE ⬆ ❌

# ✅ ↓ start coding below here ↓ ✅

html_document = e + c + g + a + f + h + d + b
print(html_document)
