import random

def get_randomInt():
	# ✅↓ Write your code here ↓✅
	random_number = random.randrange(1,13)
	return random_number

# ❌ ↓ DON'T CHANGE THE CODE BELOW ↓ ❌
print(get_randomInt())
