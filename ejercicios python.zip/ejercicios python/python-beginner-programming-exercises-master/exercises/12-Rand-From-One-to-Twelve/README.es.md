---
tutorial: "https://www.youtube.com/watch?v=tqZIlc1gVi8"
---

# `12` Rand From One to Twelve

## 📝 Instrucciones:

1. Cambia lo que necesites cambiar para hacer que el algoritmo imprima números enteros aleatorios entre 1 y 12.

2. Esta vez, utiliza la función `randrange()`.

## 💡 Pistas:

+ Debería imprimir números entre 1 y 12, no entre 0 y 12.

+ Este ejercicio es super simple, ¡no te compliques! 😃
