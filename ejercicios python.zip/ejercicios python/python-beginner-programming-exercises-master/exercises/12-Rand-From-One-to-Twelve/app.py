import random

def get_randomInt():
	# ✅↓ Write your code here ↓✅
	return None

# ❌ ↓ DON'T CHANGE THE CODE BELOW ↓ ❌
print(get_randomInt())
