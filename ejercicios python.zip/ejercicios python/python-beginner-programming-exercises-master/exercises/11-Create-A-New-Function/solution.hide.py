import random

# ✅↓ Write your code here ↓✅
def generate_random():
    result = random.randint(0,9)
    return result

print(generate_random())
