import random

# ✅↓ Write your code here ↓✅
