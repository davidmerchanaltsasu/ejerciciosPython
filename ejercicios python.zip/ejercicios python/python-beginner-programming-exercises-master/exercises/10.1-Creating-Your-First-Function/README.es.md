---
tutorial: "https://www.youtube.com/watch?v=ePn8AzCG57Y"
---

# `10.1` Creating Your First Function

## 📝 Instrucciones:
 
1. La función `add_numbers` debería devolver la suma de 2 números dados. Por favor, completa el código necesario dentro de la función para hacer que se comporte como se espera.

2. Resultado esperado: el ejercicio debería escribir el número 7 en la consola.

## 💡 Pista:

+ Hay una función `add_numbers` ya declarada, que está recibiendo dos parámetros (las variables `a` y `b`). Tú debes completar el contenido de la función con el código requerido para sumar la variable `a` con la variable `b` y devolver el resultado de la operación.

## 🔎 Importante:

+ Para practicar con más funciones, 4Geeks Academy tiene más de 20 ejercicios que se incrementan en dificultad: [https://github.com/4GeeksAcademy/python-functions-programming-exercises](https://github.com/4GeeksAcademy/python-functions-programming-exercises).

¡Inténtalos, y luego regresa! 😃  

