def add_numbers(a,b):
	# This is the function's body ✅↓ Write your code here ↓✅
	

# ❌ ↓ DON'T CHANGE THE CODE BELOW ↓ ❌
print(add_numbers(3,4))
