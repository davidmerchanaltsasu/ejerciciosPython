user_input = int(input('How many people are coming to your wedding?\n'))

# ❌ ⬆ DON'T CHANGE THE CODE ABOVE  ⬆ ❌


if user_input <= 50:
    price = 4000
# ✅ ↓ Your code here ↓ ✅


# ❌ ↓ DON'T CHANGE THE CODE BELOW ↓ ❌
print('Your wedding will cost '+str(price)+' dollars')